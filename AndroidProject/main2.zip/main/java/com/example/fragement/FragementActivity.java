package com.example.fragement;

import android.os.Bundle;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.login_project.R;

public class FragementActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {

private Fragment1 fragement1;
private Fragment2 fragement2;
private Fragment3 fragement3;
private RadioGroup main_radiogroup;
private FragmentTransaction transaction;
private FragmentManager manager;

@Override
protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragement_main);
        initFragment();
        initView();
        }

/**
 * 初始化MainActivity视图
 */
private void initView() {
        main_radiogroup = (RadioGroup) findViewById(R.id.main_radiogroup);
        main_radiogroup.setOnCheckedChangeListener(this);
        }

/**
 * 初始化所有要加载的Fragment
 */
private void initFragment() {

        fragement1 = new Fragment1();
        fragement2 = new Fragment2();
        fragement3 = new Fragment3();
        setDefaultFragment();
        }

/**
 * 设置默认的fragment
 */
private void setDefaultFragment() {
        manager = getSupportFragmentManager();
        transaction = manager.beginTransaction();
        transaction.replace(R.id.main_linear, fragement1);
        transaction.commit();

        }

/**
 * 点击下面一排RadioButton切换fragment
 * @param fragment
 */

private void replaceFragment(Fragment fragment){
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.main_linear,fragment);
        transaction.commit();
        }


/**
 * RadioGroup的监听
 * @param group
 * @param checkedId
 */
@Override
public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
        case R.id.main_fragement_box1:
        replaceFragment(fragement1);
        break;
        case R.id.main_fragement_box2:
        replaceFragment(fragement2);
        break;
        case R.id.main_fragement_box3:
        replaceFragment(fragement3);
        break;
        }
}
}