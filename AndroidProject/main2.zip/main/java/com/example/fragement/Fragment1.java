package com.example.fragement;

import static android.app.Activity.RESULT_OK;

import android.annotation.SuppressLint;
import android.content.res.Resources;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;

import androidx.fragment.app.Fragment;

import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.login_project.R;
import com.example.service.ViewManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;


public class Fragment1 extends Fragment implements CompoundButton.OnCheckedChangeListener{
    private Bitmap mScreenBitmap;
    private String filename = "/data/user/0/com.example.login_project/files/screenshots/screenshot.jpg";
    private static final int REQUEST_CODE = 1;
    private CheckBox checkBox1;
    private CheckBox checkBox2;
    private CheckBox checkBox3;
    private CheckBox checkBox4;
    private CheckBox checkBox5;
    private CheckBox checkBox6;
    private Button button;
    private Button button1;
    private String Selected = "";
    private String path ="";
    private static final int REQ_CODE_ACT = 0x2305;

    private CheckBox[] cb = new CheckBox[100];
    private String[] str = new String[100];
    private ImageView imageView;
    public enum Stage{
        GAME_INITIALIZE,
        GAME_OPEN,
        GAME_SCREENSHOT_FIND,
        GAME_END
    }

    private int i = 0;
    private int p = 0;

    private Stage stage = Stage.GAME_INITIALIZE;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.fragment_fragment1,null);
        checkBox1 = (CheckBox)view.findViewById(R.id.flex1);
        checkBox2 = (CheckBox)view.findViewById(R.id.flex2);
        checkBox3 = (CheckBox)view.findViewById(R.id.flex3);
        checkBox4 = (CheckBox)view.findViewById(R.id.flex4);
        checkBox5 = (CheckBox)view.findViewById(R.id.flex5);
        checkBox6 = (CheckBox)view.findViewById(R.id.flex6);
        cb[0] = checkBox1;
        cb[1] = checkBox2;
        cb[2] = checkBox3;
        cb[3] = checkBox4;
        cb[4] = checkBox5;
        cb[5] = checkBox6;
        int num = 6;
        imageView = (ImageView)view.findViewById(R.id.image_view);


//        checkBox1.setChecked(true);  //设置checkBox的初始值
        checkBox1.setOnCheckedChangeListener(this);
        checkBox2.setOnCheckedChangeListener(this);
        checkBox3.setOnCheckedChangeListener(this);
        checkBox4.setOnCheckedChangeListener(this);
        checkBox5.setOnCheckedChangeListener(this);
        checkBox6.setOnCheckedChangeListener(this);
        button1 = (Button) view.findViewById(R.id.bt_cancle);
        button = (Button) view.findViewById(R.id.m_bt_start);

        button1.setOnClickListener(v -> {
            for (int i = 0; i<num;i++){
                if (cb[i].isChecked()){
                    cb[i].setChecked(false);
                }
            }
        });
        button.setOnClickListener(v -> {
            if(str[0] == null){
                Toast toast=Toast.makeText(getActivity(),"您未选择脚本",Toast.LENGTH_SHORT);
                toast.show();
            }else{
                //判断有没有悬浮窗权限，没有去申请
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if(!Settings.canDrawOverlays(getActivity())){
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getActivity().getPackageName()));
                        getActivity().startActivityForResult(intent, REQUEST_CODE);
                    }else {
                        ViewManager.getInstance(getActivity()).showFloatBall();
                        Intent i = new Intent(Intent.ACTION_MAIN);
                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        i.addCategory(Intent.CATEGORY_HOME);startActivity(i);
                        JSThread jsThread = new JSThread();
                        jsThread.start();
                    }
                }
            }
        });
        return view;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        CheckBox checkBox = (CheckBox) buttonView;
        if (isChecked) {
            Selected = checkBox.getTag().toString();
            str[i] = Selected;
            i += 1;
        } else {
            for (int j = 0;j < i;j++){
                if (str[j].matches(checkBox.getTag().toString().trim())){
                    p = j;
                }
            }
            for(int j=p;j<str.length-1;j++){
                if(str[j] != null){//从P点开始后面的数向前移动，直到后面的数字为0
                    str[j]=str[j+1];
                }
            }
            i -= 1;
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {
            case REQUEST_CODE:
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
                if (!Settings.canDrawOverlays(getActivity())) {
                    Toast toast=Toast.makeText(getActivity(),"悬浮窗权限未开启，请在设置中手动打开",Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }
                ViewManager.getInstance(getActivity()).showFloatBall();
                break;
            case REQ_CODE_ACT: {
                if (resultCode == RESULT_OK && data != null) {
                    path = data.getData().toString();
                    Log.i("pass",path);
                }
                else{
                    Log.i("picture","You got wrong.");
                }
            }
            break;
        }
    }
    //解析json的线程
    class JSThread extends Thread{
        @Override
        public void run() {
            try {
                sleep(5000);
                doByStep(0);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public void doByStep(int index) throws JSONException, InterruptedException {
        InputStream inputStream = getResources().openRawResource(R.raw.test);
        JSONArray array = new JSONArray(getString(inputStream));
        JSONObject obj = null;
        String url = null;
        String type = null;
        switch (getStage()){
            case GAME_INITIALIZE:
                if (inputStream != null){
                    setStage(Stage.GAME_OPEN);
                    doByStep(index);
                }else {
                    Toast toast=Toast.makeText(getActivity(),"没有找到游戏相关脚本",Toast.LENGTH_SHORT);
                    toast.show();
                }
                break;
            case GAME_OPEN:
                obj = array.getJSONObject(index);
                type = obj.getString("type");
                url = obj.getString("url");
                String[] parts = url.split("/");
                if (type.matches("open")){
                    try {
                        /*
                        Intent intent = new Intent();
                        intent.setClassName(parts[0], parts[1]);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        */
                    }catch (Exception e) {
                        // 进行异常处理或其他操作
                        e.printStackTrace();
                        // 如果无法处理异常，可以选择将其重新抛出
                        throw e;
                    }
                    // 截图判断是否进入 进入则进入找截图

                    setStage(Stage.GAME_SCREENSHOT_FIND);
                    doByStep(++index);
                }else {
                    Toast toast=Toast.makeText(getActivity(),"脚本不正确",Toast.LENGTH_SHORT);
                    toast.show();
                }
                break;
            case GAME_SCREENSHOT_FIND:
                obj = array.getJSONObject(index);
                type = obj.getString("type");
                if (type.matches("find")){
                    // 截图匹配
                    screenShotByReflect();
                    //Log.i("截图：",filename);
                    File imgFile = new File(filename);
                    if(imgFile.exists()) {
                        Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath()); // 从文件路径解码 Bitmap
                        imageView.setImageBitmap(bitmap); // 设置 ImageView 的图片为解码后的 Bitmap
                    }else {
                        Log.i("截图：","截图不存在");
                    }
                    // 按键点击
                    Thread.sleep(5000);
                    Log.i("画面等待","5秒");
                    //当前画面比对，比对后进入下一步骤
                }else {
                    setStage(Stage.GAME_END);
                }
                doByStep(++index);
                break;
            case GAME_END:
                setStage(Stage.GAME_INITIALIZE);
                break;
        }
    }
    private void screenShotByReflect(){

    }
    public static String getString(InputStream inputStream) {

        InputStreamReader inputStreamReader = null;

        try {

            inputStreamReader = new InputStreamReader(inputStream, "gbk");

        } catch (UnsupportedEncodingException e1) {

            e1.printStackTrace();

        }

        BufferedReader reader = new BufferedReader(inputStreamReader);

        StringBuffer sb = new StringBuffer("");

        String line;

        try {

            while ((line = reader.readLine()) != null) {

                sb.append(line);

                sb.append("\n");

            }

        } catch (IOException e) {

            e.printStackTrace();

        }

        return sb.toString();

    }
    public void setStage(Stage st){
        stage = st;
    }
    public Stage getStage(){
        return stage;
    }



}
