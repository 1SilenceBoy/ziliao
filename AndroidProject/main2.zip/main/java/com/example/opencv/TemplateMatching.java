package com.example.opencv;




import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class TemplateMatching {
	pubilc static int[] getXYPosition(String yuan_path, String moban_path){
		int position[2];
		// 读取原始图像和模板图像
        Mat source = Imgcodecs.imread(yuan_path);
        Mat template = Imgcodecs.imread(moban_path);
		
		// 创建一个用于存储匹配结果的矩阵
        Mat result = new Mat();

        // 使用模板匹配算法进行匹配
        Imgproc.matchTemplate(source, template, result, Imgproc.TM_CCOEFF_NORMED);

        // 获取最佳匹配位置的坐标
        Core.MinMaxLocResult mmr = Core.minMaxLoc(result);
        Point matchLoc = mmr.maxLoc;
		
	    position[0] = matchLoc.x;
		position[1] = matchLoc.y;
		
		return a;
	}
}

