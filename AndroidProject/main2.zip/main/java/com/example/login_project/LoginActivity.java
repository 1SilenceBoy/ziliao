package com.example.login_project;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.JDBC.Dao;
import com.example.JDBC.Item;
import com.example.fragement.FragementActivity;
import com.example.game.GameActivity;
import com.example.screen.ScreenActivity;

import org.opencv.android.OpenCVLoader;

import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;



public class LoginActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {
    //    private LoginActivityBinding binding;
    private View loginLayout;
    private RadioButton btnMan;
    private RadioButton btnWoman;
    private String TextSex="";
    private Button button_concern;
    private RadioGroup rg_sex;
    private String usernameStr;
    private String passwdStr;
    private EditText username;
    private EditText passwd;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private static final String TAG = "MainActivity活动";
    private List<Item> itemList = new ArrayList<>();

    private  boolean isConnect = true;

    // 获取当前usb连接状态
    private static BroadcastReceiver UsbReceiver = null;
    private static IntentFilter filter = null;
    private boolean isUSBConnected = false;


    private static URL url;
    private static HttpURLConnection con;
    private static int state = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        binding = LoginActivityBinding.inflate(getLayoutInflater());
//        View view = binding.getRoot();
        //requestWindowFeature(Window.FEATURE_CUSTOM_TITLE); // 注意顺序
        setContentView(R.layout.login_activity);
        ScreenActivity.Init(this);
        //getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.setting_top);//注意顺序
        //初始化界面
        loginLayout = findViewById(R.id.loglayout);
        //初始化按钮
        button_concern = findViewById(R.id.Button_concern);
        //初始化编辑框
        username = findViewById(R.id.phone);
        passwd = findViewById(R.id.ediTxt_userName);
        sharedPreferences = getSharedPreferences("data",MODE_PRIVATE);
        editor = sharedPreferences.edit();
        username.setText(sharedPreferences.getString("username",""));
        passwd.setText(sharedPreferences.getString("password",""));
        // 判断网络是否连接
        if(isNetConnected(LoginActivity.this)){
            initLogin();
        }else {
            isConnect = false;
        }
        // 判断当前是否有USB设备
        if (UsbReceiver == null) {
            UsbReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                   //UsbDevice usbDevice = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    String action = intent.getAction();
                    if (action.equals("android.hardware.usb.action.USB_STATE")) {
                        boolean connected = intent.getExtras().getBoolean("connected");
                        if (connected) {
                            if (!isUSBConnected) {
                                isUSBConnected = true;
                            }
                        } else {
                            if (isUSBConnected) {
                                isUSBConnected = false;
                                Toast toast1=Toast.makeText(LoginActivity.this,"设备拔出",Toast.LENGTH_SHORT);
                                toast1.setGravity(Gravity.CENTER, 0, 0);
                                toast1.show();
                            }
                        }
                    } else {
                    }
                }
            };
        }
        if (filter == null) {
            filter = new IntentFilter();
            filter.addAction("android.hardware.usb.action.USB_STATE");
            // 注册广播
            registerReceiver(UsbReceiver, filter);
        }
        initLoadOpenCV();
        //确定按钮的点击事件
        button_concern.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = passwd.getText().toString().trim();
            if (!isConnect){
                Toast toast=Toast.makeText(LoginActivity.this,"请连接网络,连接网络后,请重启应用!",Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
                toast.show();
            } else if(user.equals("")){
                Toast toast=Toast.makeText(LoginActivity.this,"账号不能为空",Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
                toast.show();
            } else if (pass.equals("")) {
                Toast toast=Toast.makeText(LoginActivity.this,"密码不能为空",Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
                toast.show();
            } else if (CheckLogin(user,pass) == 0){
                editor.putString("username",user);
                editor.putString("password",pass);
                editor.commit();
                Toast toast = Toast.makeText(LoginActivity.this,"用户验证成功",Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
                toast.show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // 在这里执行需要等待的操作
                        // 例如，在5秒后执行某个方法或更新UI等
                        Toast toast2 = null;
                        if(isUSBConnected){
                            toast2 = Toast.makeText(LoginActivity.this,"芯片验证成功",Toast.LENGTH_SHORT);
                        }else {
                            toast2 = Toast.makeText(LoginActivity.this,"芯片验证失败",Toast.LENGTH_SHORT);
                        }
                        toast2.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
                        toast2.show();
                    }
                }, 2000);
                ScheduledExecutorService scheduledExecutor = Executors.newScheduledThreadPool(1);
                scheduledExecutor.schedule(new Runnable() {
                    @Override
                    public void run() {
                        //登录成功页面跳转
                        //Intent intent=new Intent(LoginActivity.this, MainActivity.class);
                        Intent intent = null;
                        if(isUSBConnected){
                            intent = new Intent(LoginActivity.this, GameActivity.class);
                        }else {
                            //intent = new Intent(LoginActivity.this, other.class);
                            intent = new Intent(LoginActivity.this, GameActivity.class);
                        }
                        startActivity(intent);
                    }
                }, 6, TimeUnit.SECONDS);
            }else if (CheckLogin(user,pass) == 1){
                Toast toast=Toast.makeText(LoginActivity.this,"密码错误",Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
                toast.show();
            } else {
                Toast toast=Toast.makeText(LoginActivity.this,"无此账号,请联络xxx@qq.com购买账号",Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100);
                toast.show();
            }
        });
    }
    private void initLogin(){
        MyThread myThread = new MyThread();
        Thread thread = new Thread(myThread);
        thread.start();
    }

    private class MyThread implements Runnable{
        @Override
        public void run() {
            Dao dao = new Dao();
            try {
                itemList = dao.waveList();
                Log.d(TAG, "run: 数据库数据读取成功");
            } catch (SQLException e) {
                e.printStackTrace();
                Log.d(TAG, "run: " +
                        "数据库数据读取失败");
            }
        }
    }
    private int CheckLogin(String user,String pass){
        // 0 账号密码正确
        // 1 账号正确密码错误
        // 2 账号错误
        Iterator<Item> it = itemList.listIterator();
        while(it.hasNext()) {
            Item items = it.next();
            if(user.matches(items.getUsername()) && pass.matches(items.getPassword())){
                return 0;
            }else if(user.matches(items.getUsername()) && !pass.matches(items.getPassword())){
                return 1;
            }else{
                // Do nothing  continue
            }
        }
        return 2;
    }
    //CheckBox的重载
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
    }
    /**
     * 判断网络是否连接
     */
    public static boolean isNetConnected(Context context) {
        if (context != null) {
            ConnectivityManager mConnectivityManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();
            if (mNetworkInfo != null) {
                Log.d(TAG, "当前是否有网络：" + mNetworkInfo.isAvailable() + "");
                return mNetworkInfo.isAvailable();
            }
        }
        Log.d(TAG, "当前是否有网络：false");
        return false;
    }


    /**
     * 功能：检测当前URL是否可连接或是否有效,
     * 描述：最多连接网络 x次, 如果 x 次都不成功，视为该地址不可用
     * @return true是可以上网，false是不能上网
     */
    public static boolean isNetOnline() {
        // Android 4.0 之后不能在主线程中请求HTTP请求
        int counts = 0;
        boolean isNetsOnline = true;
        while (counts < 2) {
            try {
                url = new URL("https://www.baidu.com");
                con = (HttpURLConnection) url.openConnection();
                state = con.getResponseCode();
                Log.e("FragmentNet", "isNetOnline counts: " + counts + "=state: " + state);
                if (state == 200) {
                    isNetsOnline = true;
                }
                break;
            } catch (Exception ex) {
                isNetsOnline = false;
                counts++;
                Log.e("FragmentNet", "isNetOnline URL不可用，连接第 " + counts + " 次");
                continue;
            }
        }
        return isNetsOnline;

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 销毁广播
        if (UsbReceiver != null) {
            unregisterReceiver(UsbReceiver);
        }
    }
    private void initLoadOpenCV(){
        boolean success = OpenCVLoader.initDebug();
        if(success){
            Log.i(TAG,"SUCCESS");
        }else {
            Log.i(TAG,"FAILED");
        }
    }
}