package com.example.JDBC;

import android.util.Log;

import java.sql.*;

public class DBUtils {

    private static String driver = "com.mysql.jdbc.Driver";
    private static Connection conn;
    private static String url =  "jdbc:mysql://39.106.94.239:3306/wp_test?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static String user = "root";
    private static String password = "123456";

    public static Connection getConn(){
        try {
            Class.forName(driver);
            Log.d("数据库连接", "getConn: 数据库驱动加载成功");
            conn = DriverManager.getConnection(url,user,password);
            Log.d("数据库连接", "getConn: 数据库连接成功");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            Log.d("数据库连接", "getConn: 数据库连接失败");
            return  null;
        }
        return conn;
    }

    public static void closeConn(Connection conn, PreparedStatement preStmt, ResultSet rs){
        if(rs!=null){
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(preStmt!=null){
            try {
                preStmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if(conn!=null){
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
