package com.example.service;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.login_project.R;

import org.greenrobot.eventbus.EventBus;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;


public class ViewManager {
    FloatingView floatBall;
    WindowManager windowManager;
    public static ViewManager manager;
    Context context;

    private WindowManager.LayoutParams layoutParams;
    private  Bitmap screenshotBitmap;

    private ViewManager(Context context) {
        this.context = context;

    }

    public static ViewManager getInstance(Context context) {
        if (manager == null) {
            manager = new ViewManager(context);
        }
        return manager;
    }
    public void showFloatBall() {
        floatBall = new FloatingView(context);
        floatBall.setBackgroundResource(R.drawable.xuanfu);
        windowManager = (WindowManager)context.getSystemService(Context.WINDOW_SERVICE);
        int screenWidth = 0, screenHeight = 0;
        if (windowManager != null) {
            //获取屏幕的宽和高
            Point point = new Point();
            windowManager.getDefaultDisplay().getSize(point);
            screenWidth = point.x;
            screenHeight = point.y;
            layoutParams = new WindowManager.LayoutParams();
//            layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
//            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
            layoutParams.width = 200;
            layoutParams.height = 200;
            //设置type
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                //26及以上必须使用TYPE_APPLICATION_OVERLAY   @deprecated TYPE_PHONE
                layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            } else {
                layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
            }
            //设置flags
            layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED;
            layoutParams.gravity = Gravity.START | Gravity.TOP;
            //背景设置成透明
            layoutParams.format = PixelFormat.TRANSPARENT;
            layoutParams.x = screenWidth;
            layoutParams.y = screenHeight / 2;

        }

        windowManager.addView(floatBall, layoutParams);

        floatBall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EventBus.getDefault().post(MyAccessibilityService.BACK);
                Toast.makeText(context, "点击了悬浮球 执行后退操作", Toast.LENGTH_SHORT).show();
                ImageMatching();

            }
        });

        floatBall.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                EventBus.getDefault().post(MyAccessibilityService.HOME);
                Toast.makeText(context, "长按了悬浮球  执行返回桌面", Toast.LENGTH_SHORT).show();
                return false;
            }
        });

        floatBall.setOnTouchListener(new View.OnTouchListener() {
                float startX;
                float startY;
                float tempX;
                float tempY;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            startX = event.getRawX();
                            startY = event.getRawY();

                            tempX = event.getRawX();
                            tempY = event.getRawY();
                            break;
                        case MotionEvent.ACTION_MOVE:
                            float dx = event.getRawX() - startX;
                            float dy = event.getRawY() - startY;
                            //计算偏移量，刷新视图
                            layoutParams.x += dx;
                            layoutParams.y += dy;
                            windowManager.updateViewLayout(floatBall, layoutParams);
                            startX = event.getRawX();
                            startY = event.getRawY();
                            break;
                        case MotionEvent.ACTION_UP:
                            //判断松手时View的横坐标是靠近屏幕哪一侧，将View移动到依靠屏幕
                            float endX = event.getRawX();
                            float endY = event.getRawY();
                            if (endX < getScreenWidth() / 2) {
                                endX = 0;
                            } else {
                                endX = getScreenWidth() - floatBall.width;
                            }
                            layoutParams.x = (int) endX;
                            windowManager.updateViewLayout(floatBall, layoutParams);
                            //如果初始落点与松手落点的坐标差值超过6个像素，则拦截该点击事件
                            //否则继续传递，将事件交给OnClickListener函数处理
                            if (Math.abs(endX - tempX) > 6 && Math.abs(endY - tempY) > 6) {
                                return true;
                            }
                            break;
                    }
                    return false;
                }

        });
    }

    public int getScreenWidth() {
        return windowManager.getDefaultDisplay().getWidth();
    }

    public void ImageMatching(){
        // 读取原始图像和模板图像
        //Mat source = Imgcodecs.imread("/path/to/one0.jpg");
        //Mat template = Imgcodecs.imread("/drawable/two2.jpg");

        int imageResId = R.drawable.guanggao; // 替换为资源ID
        int imageRes = R.drawable.lingqian;
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), imageResId);
        Bitmap bp = BitmapFactory.decodeResource(context.getResources(), imageRes);
        Mat source = new Mat();
        Mat template =new Mat();
        Utils.bitmapToMat(bitmap, source);
        Utils.bitmapToMat(bp, template);

        // 检查图像是否成功加载
        if (source.empty() || template.empty()) {
            System.out.println("无法加载图像");
            return;
        }

       /* Size newSize = new Size(source.cols(), source.rows());
        Imgproc.resize(template, template, newSize);

        // 检查图像和模板图像的尺寸是否匹配
        if (!source.size().equals(template.size())) {
            System.out.println("图像尺寸不匹配");
            return;
        }
        */
        System.out.println("原始图像尺寸: " + source.cols() + " x " + source.rows());
        System.out.println("模板图像尺寸: " + template.cols() + " x " + template.rows());
        // 创建结果矩阵
        int resultCols = source.cols() - template.cols() + 1;
        int resultRows = source.rows() - template.rows() + 1;
        Mat result = new Mat(resultRows, resultCols, CvType.CV_32FC1);

        // 进行模板匹配
        Imgproc.matchTemplate(source, template, result, Imgproc.TM_CCOEFF_NORMED);

        // 获取匹配结果的最大值和对应位置
        Core.MinMaxLocResult mmr = Core.minMaxLoc(result);

        // 获取最佳匹配位置
        org.opencv.core.Point matchLoc = mmr.maxLoc;
        // 输出匹配位置的屏幕坐标
        System.out.println("匹配位置的屏幕坐标：x = " + matchLoc.x + ", y = " + matchLoc.y);

        // 在原始图像上绘制矩形框标记匹配位置
        Imgproc.rectangle(source, matchLoc, new org.opencv.core.Point(matchLoc.x + template.cols(), matchLoc.y + template.rows()), new Scalar(0, 255, 0), 2);

        // 显示绘制了矩形框的图像
        //Imgproc.imshow("Result", source);
        //HighGui.waitKey(0);

        source.release();
        template.release();
    }


}
