package com.example.login_project;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class other extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.error);
    }
}
