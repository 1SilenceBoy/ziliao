package com.example.game;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fragement.Fragment1;
import com.example.login_project.R;
import com.example.screen.ScreenActivity;
import com.example.service.ViewManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;


public class GameActivity extends AppCompatActivity {
    private static final int REQUEST_CODE = 1;
    public enum Stage{
        GAME_INITIALIZE,
        GAME_OPEN,
        GAME_SCREENSHOT_FIND,
        GAME_END
    }
    private Stage stage = Stage.GAME_INITIALIZE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_fragment2);
    }
    public void gameUpdate(View view)
    {
        Toast.makeText(this, "点击了更新游戏", Toast.LENGTH_SHORT).show();
    }
    public void gameInstall(View view)
    {
        Toast.makeText(this, "点击了安装游戏", Toast.LENGTH_SHORT).show();
        ScreenActivity.GetScreen(3000, 2);
    }
    public void gameStart(View view)
    {
        //判断有没有悬浮窗权限，没有去申请
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if(!Settings.canDrawOverlays(this)){
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_CODE);
            }else {
                ViewManager.getInstance(this).showFloatBall();
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.addCategory(Intent.CATEGORY_HOME);startActivity(i);
                JSThread jsThread = new JSThread();
                jsThread.start();
            }
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE:
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
                if (!Settings.canDrawOverlays(this)) {
                    Toast toast = Toast.makeText(this, "悬浮窗权限未开启，请在设置中手动打开", Toast.LENGTH_SHORT);
                    toast.show();
                    return;
                }
                ViewManager.getInstance(this).showFloatBall();
                break;
        }
    }

    class JSThread extends Thread{
        @Override
        public void run() {
            try {
                sleep(5000);
                doByStep(0);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void doByStep(int index) throws JSONException, InterruptedException {
        InputStream inputStream = getResources().openRawResource(R.raw.test);
        JSONArray array = new JSONArray(getString(inputStream));
        JSONObject obj = null;
        String url = null;
        String type = null;
        switch (getStage()){
            case GAME_INITIALIZE:
                if (inputStream != null){
                    setStage(Stage.GAME_OPEN);
                    doByStep(index);
                }else {
                    Toast toast=Toast.makeText(this,"没有找到游戏相关脚本",Toast.LENGTH_SHORT);
                    toast.show();
                }
                break;
            case GAME_OPEN:
                obj = array.getJSONObject(index);
                type = obj.getString("type");
                url = obj.getString("url");
                String[] parts = url.split("/");
                if (type.matches("open")){
                    try {
                        /*
                        Intent intent = new Intent();
                        intent.setClassName(parts[0], parts[1]);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        */
                    }catch (Exception e) {
                        // 进行异常处理或其他操作
                        e.printStackTrace();
                        // 如果无法处理异常，可以选择将其重新抛出
                        throw e;
                    }
                    // 截图判断是否进入 进入则进入找截图

                    setStage(Stage.GAME_SCREENSHOT_FIND);
                    doByStep(++index);
                }else {
                    Toast toast=Toast.makeText(this,"脚本不正确",Toast.LENGTH_SHORT);
                    toast.show();
                }
                break;
            case GAME_SCREENSHOT_FIND:
                obj = array.getJSONObject(index);
                type = obj.getString("type");
                if (type.matches("find")){
                    // 截图匹配
                    ScreenActivity.GetScreen(1000, 5);
                    // 按键点击
                    Thread.sleep(5000);
                    Log.i("画面等待","5秒");
                    //当前画面比对，比对后进入下一步骤
                }else {
                    setStage(Stage.GAME_END);
                }
                doByStep(++index);
                break;
            case GAME_END:
                setStage(Stage.GAME_INITIALIZE);
                break;
        }
    }
    public static String getString(InputStream inputStream) {

        InputStreamReader inputStreamReader = null;

        try {

            inputStreamReader = new InputStreamReader(inputStream, "gbk");

        } catch (UnsupportedEncodingException e1) {

            e1.printStackTrace();

        }

        BufferedReader reader = new BufferedReader(inputStreamReader);

        StringBuffer sb = new StringBuffer("");

        String line;

        try {

            while ((line = reader.readLine()) != null) {

                sb.append(line);

                sb.append("\n");

            }

        } catch (IOException e) {

            e.printStackTrace();

        }

        return sb.toString();

    }
    public void setStage(Stage st){
        stage = st;
    }
    public Stage getStage(){
        return stage;
    }

}
