package com.example.JDBC;

import android.util.Log;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Dao {

    private static Connection conn;
    private static PreparedStatement preStmt;
    private static ResultSet rs;

    private String sql2 = "select * from user ";

    public List<Item> waveList() throws SQLException {
        List<Item> list = new ArrayList<>();
        conn = DBUtils.getConn();
        Log.d("数据库连接返回值", "login: "+conn);
        preStmt = conn.prepareStatement(sql2);
        rs = preStmt.executeQuery();
        while(rs.next()){
            Item item = new Item();
            item.setUsername(rs.getString(2));
            item.setPassword(rs.getString(3));
            list.add(item);
        }
        DBUtils.closeConn(conn,preStmt,rs);
        return list;
    }

}