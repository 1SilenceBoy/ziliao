[{"type":"open","url":"com.xfcg.qc.wbqy/com.unity3d.player.UnityPlayerActivity","time":500},
{"type":"find","url":"xxx","time":500},
{"type":"swipe","url":"xxx","time":500},
{"type":"end","url":"com.xfcg.qc.wbqy/com.unity3d.player.UnityPlayerActivity","time":500}
]